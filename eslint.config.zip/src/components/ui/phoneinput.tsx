import { useState, useEffect, useRef, InputHTMLAttributes } from "react";
import { Icon } from "@iconify/react";
import Input from "./input";

interface Country {
  name: string;
  dialCode: string;
  flag: string;
  format?: string;
}

interface PhoneInputProps
  extends Omit<InputHTMLAttributes<HTMLInputElement>, "size" | "type" | "onChange"> {
  label?: string;
  message?: string;
  state?: "danger" | "disabled" | "success";
  labelAlignment?: "vertical" | "horizontal";
  inputSize?: "default" | "sm";
  radius?: "none" | "lg" | "xl";
  onChange?: (value: string, country: Country) => void;
  defaultCountry?: string;
}

// Country data with dial codes and flags (using Iconify emojione flag icons)
const countries: Country[] = [
  { name: "Afghanistan", dialCode: "+93", flag: "emojione-v1:flag-for-afghanistan" },
  { name: "Algeria", dialCode: "+213", flag: "emojione-v1:flag-for-algeria" },
  { name: "Angola", dialCode: "+244", flag: "emojione-v1:flag-for-angola" },
  { name: "Argentina", dialCode: "+54", flag: "emojione-v1:flag-for-argentina" },
  { name: "Australia", dialCode: "+61", flag: "emojione-v1:flag-for-australia" },
  { name: "Bahrain", dialCode: "+973", flag: "emojione-v1:flag-for-bahrain" },
  { name: "Bangladesh", dialCode: "+880", flag: "emojione-v1:flag-for-bangladesh" },
  { name: "Belarus", dialCode: "+375", flag: "emojione-v1:flag-for-belarus" },
  { name: "Bhutan", dialCode: "+975", flag: "emojione-v1:flag-for-bhutan" },
  { name: "Botswana", dialCode: "+267", flag: "emojione-v1:flag-for-botswana" },
  { name: "Brazil", dialCode: "+55", flag: "emojione-v1:flag-for-brazil" },
  { name: "Cameroon", dialCode: "+237", flag: "emojione-v1:flag-for-cameroon" },
  { name: "Canada", dialCode: "+1", flag: "emojione-v1:flag-for-canada" },
  { name: "China", dialCode: "+86", flag: "emojione-v1:flag-for-china" },
  { name: "Congo (DRC)", dialCode: "+243", flag: "emojione-v1:flag-for-congo-kinshasa" },
  { name: "Congo (Republic)", dialCode: "+242", flag: "emojione-v1:flag-for-congo-brazzaville" },
  { name: "Egypt", dialCode: "+20", flag: "emojione-v1:flag-for-egypt" },
  { name: "Eswatini", dialCode: "+268", flag: "emojione-v1:flag-for-flag-eswatini" },
  { name: "Ethiopia", dialCode: "+251", flag: "emojione-v1:flag-for-ethiopia" },
  { name: "Fiji", dialCode: "+679", flag: "emojione-v1:flag-for-fiji" },
  { name: "France", dialCode: "+33", flag: "emojione-v1:flag-for-france" },
  { name: "French Polynesia", dialCode: "+689", flag: "emojione-v1:flag-for-french-polynesia" },
  { name: "Georgia", dialCode: "+995", flag: "emojione-v1:flag-for-georgia" },
  { name: "Germany", dialCode: "+49", flag: "emojione-v1:flag-for-germany" },
  { name: "Ghana", dialCode: "+233", flag: "emojione-v1:flag-for-ghana" },
  { name: "India", dialCode: "+91", flag: "emojione-v1:flag-for-india" },
  { name: "Indonesia", dialCode: "+62", flag: "emojione-v1:flag-for-indonesia" },
  { name: "Iran", dialCode: "+98", flag: "emojione-v1:flag-for-iran" },
  { name: "Italy", dialCode: "+39", flag: "emojione-v1:flag-for-italy" },
  { name: "Ivory Coast", dialCode: "+225", flag: "emojione-v1:flag-for-cote-divoire" },
  { name: "Jamaica", dialCode: "+1", flag: "emojione-v1:flag-for-jamaica" },
  { name: "Japan", dialCode: "+81", flag: "emojione-v1:flag-for-japan" },
  { name: "Kazakhstan", dialCode: "+7", flag: "emojione-v1:flag-for-kazakhstan" },
  { name: "Kenya", dialCode: "+254", flag: "emojione-v1:flag-for-kenya" },
  { name: "Kiribati", dialCode: "+686", flag: "emojione-v1:flag-for-kiribati" },
  { name: "Libya", dialCode: "+218", flag: "emojione-v1:flag-for-libya" },
  { name: "Madagascar", dialCode: "+261", flag: "emojione-v1:flag-for-madagascar" },
  { name: "Malaysia", dialCode: "+60", flag: "emojione-v1:flag-for-malaysia" },
  { name: "Malawi", dialCode: "+265", flag: "emojione-v1:flag-for-malawi" },
  { name: "Mali", dialCode: "+223", flag: "emojione-v1:flag-for-mali" },
  { name: "Marshall Islands", dialCode: "+692", flag: "emojione-v1:flag-for-marshall-islands" },
  { name: "Mauritius", dialCode: "+230", flag: "emojione-v1:flag-for-mauritius" },
  { name: "Mexico", dialCode: "+52", flag: "emojione-v1:flag-for-mexico" },
  { name: "Micronesia", dialCode: "+691", flag: "emojione-v1:flag-for-micronesia" },
  { name: "Mongolia", dialCode: "+976", flag: "emojione-v1:flag-for-mongolia" },
  { name: "Morocco", dialCode: "+212", flag: "emojione-v1:flag-for-morocco" },
  { name: "Mozambique", dialCode: "+258", flag: "emojione-v1:flag-for-mozambique" },
  { name: "Myanmar", dialCode: "+95", flag: "emojione-v1:flag-for-myanmar" },
  { name: "Namibia", dialCode: "+264", flag: "emojione-v1:flag-for-namibia" },
  { name: "Nepal", dialCode: "+977", flag: "emojione-v1:flag-for-nepal" },
  { name: "Netherlands", dialCode: "+31", flag: "emojione-v1:flag-for-netherlands" },
  { name: "New Caledonia", dialCode: "+687", flag: "emojione-v1:flag-for-new-caledonia" },
  { name: "New Zealand", dialCode: "+64", flag: "emojione-v1:flag-for-new-zealand" },
  { name: "Nigeria", dialCode: "+234", flag: "emojione-v1:flag-for-nigeria" },
  { name: "Pakistan", dialCode: "+92", flag: "emojione-v1:flag-for-pakistan" },
  { name: "Papua New Guinea", dialCode: "+675", flag: "emojione-v1:flag-for-papua-new-guinea" },
  { name: "Philippines", dialCode: "+63", flag: "emojione-v1:flag-for-philippines" },
  { name: "Poland", dialCode: "+48", flag: "emojione-v1:flag-for-poland" },
  { name: "Puerto Rico", dialCode: "+1", flag: "emojione-v1:flag-for-puerto-rico" },
  { name: "Qatar", dialCode: "+974", flag: "emojione-v1:flag-for-qatar" },
  { name: "Russia", dialCode: "+7", flag: "emojione-v1:flag-for-russia" },
  { name: "Rwanda", dialCode: "+250", flag: "emojione-v1:flag-for-rwanda" },
  { name: "Saudi Arabia", dialCode: "+966", flag: "emojione-v1:flag-for-saudi-arabia" },
  { name: "Senegal", dialCode: "+221", flag: "emojione-v1:flag-for-senegal" },
  { name: "Seychelles", dialCode: "+248", flag: "emojione-v1:flag-for-seychelles" },
  { name: "Singapore", dialCode: "+65", flag: "emojione-v1:flag-for-singapore" },
  { name: "Solomon Islands", dialCode: "+677", flag: "emojione-v1:flag-for-solomon-islands" },
  { name: "South Africa", dialCode: "+27", flag: "emojione-v1:flag-for-south-africa" },
  { name: "South Korea", dialCode: "+82", flag: "emojione-v1:flag-for-south-korea" },
  { name: "South Sudan", dialCode: "+211", flag: "twemoji:flag-south-sudan" },
  { name: "Spain", dialCode: "+34", flag: "emojione-v1:flag-for-spain" },
  { name: "Sri Lanka", dialCode: "+94", flag: "emojione-v1:flag-for-sri-lanka" },
  { name: "Sudan", dialCode: "+249", flag: "emojione-v1:flag-for-sudan" },
  { name: "Sweden", dialCode: "+46", flag: "emojione-v1:flag-for-sweden" },
  { name: "Switzerland", dialCode: "+41", flag: "emojione-v1:flag-for-switzerland" },
  { name: "Tanzania", dialCode: "+255", flag: "emojione-v1:flag-for-tanzania" },
  { name: "Thailand", dialCode: "+66", flag: "emojione-v1:flag-for-thailand" },
  { name: "Tonga", dialCode: "+676", flag: "emojione-v1:flag-for-tonga" },
  { name: "Trinidad & Tobago", dialCode: "+1", flag: "emojione-v1:flag-for-trinidad-and-tobago" },
  { name: "Tunisia", dialCode: "+216", flag: "emojione-v1:flag-for-tunisia" },
  { name: "Turkey", dialCode: "+90", flag: "emojione-v1:flag-for-turkey" },
  { name: "Tuvalu", dialCode: "+688", flag: "emojione-v1:flag-for-tuvalu" },
  { name: "Uganda", dialCode: "+256", flag: "emojione-v1:flag-for-uganda" },
  { name: "Ukraine", dialCode: "+380", flag: "emojione-v1:flag-for-ukraine" },
  { name: "United Arab Emirates", dialCode: "+971", flag: "emojione-v1:flag-for-united-arab-emirates" },
  { name: "United Kingdom", dialCode: "+44", flag: "emojione-v1:flag-for-united-kingdom" },
  { name: "United States", dialCode: "+1", flag: "emojione-v1:flag-for-united-states" },
  { name: "Uzbekistan", dialCode: "+998", flag: "emojione-v1:flag-for-uzbekistan" },
  { name: "Vanuatu", dialCode: "+678", flag: "emojione-v1:flag-for-vanuatu" },
  { name: "Vietnam", dialCode: "+84", flag: "emojione-v1:flag-for-vietnam" },
  { name: "Zambia", dialCode: "+260", flag: "emojione-v1:flag-for-zambia" },
  { name: "Zimbabwe", dialCode: "+263", flag: "emojione-v1:flag-for-zimbabwe" },
];

const PhoneInput: React.FC<PhoneInputProps> = ({
  label,
  placeholder = "Enter phone number",
  className,
  message,
  state,
  disabled = false,
  labelAlignment = "vertical",
  inputSize = "default",
  radius = "xl",
  value = "",
  onChange,
  id,
  name,
  defaultCountry = "IN",
  ...rest
}) => {
  const [phoneNumber, setPhoneNumber] = useState(value?.toString() || "");
  const [selectedCountry, setSelectedCountry] = useState<Country>(
    countries.find((c) => c.name === defaultCountry) || countries[2]
  );
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [isFocused, setIsFocused] = useState(false);
  const [isFilled, setIsFilled] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const dropdownRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Detect country from phone number
  const detectCountryFromNumber = (number: string) => {
    if (!number) return;
    
    // Sort countries by dial code length (longest first) for accurate matching
    const sortedCountries = [...countries].sort(
      (a, b) => b.dialCode.length - a.dialCode.length
    );

    for (const country of sortedCountries) {
      const dialCodeWithoutPlus = country.dialCode.substring(1);
      if (number.startsWith(dialCodeWithoutPlus)) {
        setSelectedCountry(country);
        break;
      }
    }
  };

  // Handle numeric input only
  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const numericValue = e.target.value.replace(/[^0-9]/g, "");
    setPhoneNumber(numericValue);
    setIsFilled(!!numericValue);

    // Auto-detect country from entered number
    detectCountryFromNumber(numericValue);

    // Call parent onChange with full international format
    onChange?.(numericValue, selectedCountry);
  };

  // Handle country selection
  const handleCountrySelect = (country: Country) => {
    setSelectedCountry(country);
    setIsDropdownOpen(false);
    setSearchQuery("");
    inputRef.current?.focus();
    onChange?.(phoneNumber, country);
  };

  // Filter countries based on search
  const filteredCountries = countries.filter(
    (country) =>
      country.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      country.dialCode.includes(searchQuery)
  );

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setIsDropdownOpen(false);
        setSearchQuery("");
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const inputStyle: React.CSSProperties = {
    backgroundColor:
      state === "danger"
        ? "var(--input-bg-error)"
        : state === "success"
        ? "var(--input-bg-success)"
        : isFilled
        ? "var(--input-bg-filled)"
        : "var(--input-bg-default)",
    borderColor:
      state === "danger"
        ? "var(--input-border-error)"
        : state === "success"
        ? "var(--input-border-success)"
        : isFocused || isHovered
        ? "var(--input-border-hover)"
        : isFilled
        ? "var(--input-border-filled)"
        : "var(--input-border-default)",
    color:
      disabled || !phoneNumber
        ? "var(--input-placeholder-default)"
        : "var(--input-placeholder-filled)",
  };

  const labelStyle: React.CSSProperties = {
    color: disabled
      ? "var(--input-label-default)"
      : state === "danger"
      ? "var(--input-label-error)"
      : state === "success"
      ? "var(--input-label-success)"
      : isFocused
      ? "var(--input-label-focus)"
      : "var(--input-label-default)",
  };

  const helperStyle: React.CSSProperties = {
    color:
      state === "danger"
        ? "var(--input-helper-text-error)"
        : state === "success"
        ? "var(--input-helper-text-success)"
        : "var(--input-helper-text-default)",
  };

  const sizePadding = inputSize === "sm" ? "p-2" : "p-3";
  const sizeHeight = inputSize === "sm" ? "h-10" : "h-11";

  const radiusClass =
    radius === "none"
      ? "rounded-none border-0 border-b"
      : radius === "lg"
      ? "rounded-lg border"
      : "rounded-xl border";

  const inputBaseClass = `w-full ${radiusClass} transition-all ease-in duration-300 focus:outline-none text-sm leading-5 font-normal ${sizePadding} ${sizeHeight}`;

  const countryTextClasses = disabled
    ? "text-base-300"
    : isFilled
    ? "text-base-950 dark:text-dark-base-900"
    : "text-base-600 dark:text-dark-base-600";

  return (
    <div
      className={`flex w-full group ${
        labelAlignment === "horizontal" ? "gap-2" : "flex-col gap-2"
      } ${className || ""}`}
    >
      {label && (
        <label
          style={labelStyle}
          className={`p-text whitespace-nowrap flex-shrink-0 leading-7 ${
            labelAlignment === "horizontal" ? "pt-2" : ""
          }`}
        >
          {label}
        </label>
      )}

      <div className="w-full flex flex-col gap-2">
        <div className="relative w-full" ref={dropdownRef}>
          {/* Country selector */}
          <div
            className={`absolute w-24 left-0 top-0 bottom-0 flex items-center gap-1 pl-3 pr-3 transition-colors rounded-l-xl z-10 ${
              disabled
                ? "opacity-70 cursor-not-allowed"
                : "cursor-pointer group"
            }`}
            onClick={() => !disabled && setIsDropdownOpen(!isDropdownOpen)}
          >
            <Icon icon={selectedCountry.flag} width={20} height={20} />
            <span className={`p-text group-hover:text-primary-700 ${countryTextClasses}`}>
              {selectedCountry.dialCode}
            </span>
            <Icon
              icon="fluent:chevron-down-20-regular"
              className={`w-4 h-4 group-hover:text-primary-700 ${countryTextClasses} transition-transform ${
                isDropdownOpen ? "rotate-180" : ""
              }`}
            />
          </div>

          {/* Vertical divider */}
          <div
            className="absolute top-1/2 -translate-y-1/2 w-px h-6 bg-[var(--input-border-default)] z-10"
            style={{
              left: inputSize === "sm" ? "76px" : "96px",
              borderColor: inputStyle.borderColor,
            }}
          /> 

          <input
            ref={inputRef}
            id={id}
            name={name}
            type="tel"
            inputMode="numeric"
            pattern="[0-9]*"
            placeholder={placeholder}
            disabled={disabled}
            value={phoneNumber}
            onChange={handlePhoneChange}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
            style={inputStyle}
            className={`p-text ${inputBaseClass} pl-28 pr-3`}
            {...rest}
          />

          {/* Dropdown */}
          {isDropdownOpen && (
            <div
              className="absolute p-2 flex flex-col gap-2 left-0 w-full bg-base-50 dark:bg-dark-base-50 border border-base-200 dark:border-dark-base-200 rounded-xl shadow-lg max-h-64 overflow-hidden z-50"
              style={{ top: "calc(100% + 5px)" }}
            >
              {/* Search input */}
              <Input 
                    type="text"
                    placeholder="Search country..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full"
                    radius="lg"
                  />
              {/* <div className="p-2 border-b border-base-200 dark:border-dark-base-200 sticky top-0 bg-base-50 dark:bg-dark-base-50">
                <div className="relative">
                  <Icon
                    icon="fluent:search-20-regular"
                    className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-base-400"
                  />
                  <input
                    type="text"
                    placeholder="Search country..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-base-200 dark:border-dark-base-200 bg-base-50 dark:bg-dark-base-50 text-base-950 dark:text-dark-base-900 focus:outline-none focus:border-base-400"
                  />

                  
                </div>
              </div> */}

              {/* Country list */}
              <div className="overflow-y-auto max-h-52">
                {filteredCountries.length > 0 ? (
                  filteredCountries.map((country) => (
                    <div
                      key={country.flag}
                      onClick={() => handleCountrySelect(country)}
                      className={`flex items-center gap-3 px-3 py-2 cursor-pointer hover:bg-base-100 rounded dark:hover:bg-dark-base-100 transition-colors ${
                        selectedCountry.flag === country.flag
                          ? "bg-base-100 dark:bg-dark-base-100"
                          : ""
                      }`}
                    >
                      <Icon icon={country.flag} width={20} height={20} />
                      <span className="flex-1 text-sm text-base-950 dark:text-dark-base-900">
                        {country.name}
                      </span>
                      <span className="text-sm text-base-600 dark:text-dark-base-600">
                        {country.dialCode}
                      </span>
                    </div>
                  ))
                ) : (
                  <div className="px-3 py-4 text-center text-sm text-base-400">
                    No countries found
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {message && <p style={helperStyle}>{message}</p>}
      </div>
    </div>
  );
};

export default PhoneInput;