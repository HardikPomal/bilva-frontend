import { useState, TextareaHTMLAttributes } from "react";

interface TextareaProps
  extends Omit<TextareaHTMLAttributes<HTMLTextAreaElement>, "size"> {
  label?: string;
  message?: string;
  state?: "danger" | "disabled" | "success";
  labelAlignment?: "vertical" | "horizontal";
  
  // Custom size prop
  textareaSize?: "default" | "sm";
  
  // Radius prop
  radius?: "none" | "lg" | "xl";
}

const Textarea: React.FC<TextareaProps> = ({
  label,
  placeholder,
  className,
  message,
  state,
  disabled = false,
  labelAlignment = "vertical",
  textareaSize = "default",
  radius = "xl",
  value,
  onChange,
  id,
  name,
  rows = 4,
  ...rest
}) => {
  const [isFocused, setIsFocused] = useState(false);
  const [isFilled, setIsFilled] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const textareaStyle: React.CSSProperties = {
    backgroundColor:
      state === "danger"
        ? "var(--input-bg-error)"
        : state === "success"
        ? "var(--input-bg-success)"
        : isFilled
        ? "var(--input-bg-filled)"
        : "var(--input-bg-default)",
    borderColor:
      state === "danger"
        ? "var(--input-border-error)"
        : state === "success"
        ? "var(--input-border-success)"
        : isFocused || isHovered
        ? "var(--input-border-hover)"
        : isFilled
        ? "var(--input-border-filled)"
        : "var(--input-border-default)",
    color:
      disabled || !value
        ? "var(--input-placeholder-default)"
        : "var(--input-placeholder-filled)",
  };

  const labelStyle: React.CSSProperties = {
    color: disabled
      ? "var(--input-label-default)"
      : state === "danger"
      ? "var(--input-label-error)"
      : state === "success"
      ? "var(--input-label-success)"
      : isFocused
      ? "var(--input-label-focus)"
      : "var(--input-label-default)",
  };

  const helperStyle: React.CSSProperties = {
    color:
      state === "danger"
        ? "var(--input-helper-text-error)"
        : state === "success"
        ? "var(--input-helper-text-success)"
        : "var(--input-helper-text-default)",
  };

  // Adjust padding based on size
  const sizePadding = textareaSize === "sm" ? "p-2" : "p-3";

  // Get border radius class based on radius prop
  const radiusClass =
    radius === "none"
      ? "rounded-none border-0 border-b"
      : radius === "lg"
      ? "rounded-lg border"
      : "rounded-xl border";

  const textareaBaseClass = `w-full ${radiusClass} transition-all ease-in duration-300 focus:outline-none p-text ${sizePadding} min-h-[80px]`;

  return (
    <div
      className={`flex w-full group ${
        labelAlignment === "horizontal" ? "gap-2" : "flex-col gap-2"
      } ${className || ""}`}
    >
      {label && (
        <label
          style={labelStyle}
          className={`p-text whitespace-nowrap flex-shrink-0 leading-7 ${
            labelAlignment === "horizontal" ? "pt-2" : ""
          }`}
        >
          {label}
        </label>
      )}

      <div className="w-full flex flex-col gap-2">
        <textarea
          id={id}
          name={name}
          placeholder={placeholder}
          disabled={disabled}
          value={value}
          rows={rows}
          onChange={(e) => {
            onChange?.(e);
            setIsFilled(!!e.target.value);
          }}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
          style={textareaStyle}
          className={`p-text ${textareaBaseClass}`}
          {...rest}
        />

        {/* Message below textarea */}
        {message && <p style={helperStyle}>{message}</p>}
      </div>
    </div>
  );
};

export default Textarea;