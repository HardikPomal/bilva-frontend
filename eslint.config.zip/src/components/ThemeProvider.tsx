"use client";

import { useEffect } from "react";

export default function ThemeProvider() {
  useEffect(() => {
    const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)");

    const updateClass = (isDark: boolean) => {
      document.documentElement.classList.toggle("dark", isDark);
    };

    updateClass(mediaQuery.matches); // Initial set

    const listener = (e: MediaQueryListEvent) => updateClass(e.matches);
    mediaQuery.addEventListener("change", listener);

    return () => mediaQuery.removeEventListener("change", listener);
  }, []);

  return null;
}
