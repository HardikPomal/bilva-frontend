"use client";

import Button from "@/components/ui/button";
import Input from "@/components/ui/input";
import PhoneInput from "@/components/ui/phoneinput";
import Textarea from "@/components/ui/textarea";

export default function Home() {
  return (
    <>
      <section className="components container mx-auto flex flex-col gap-6 py-20">
        <Input
          placeholder="Search here..."
          shortcutKey="ctrl+k" // functional binding
          onShortcutPress={() => alert("CTRL+K pressed")}
          onEnterPress={() => alert("Enter pressed")}
          shortcutBase="CTRL"
          shortcutKeyDisplay="K" // visual badge
          leftIcon="fluent:search-20-regular"
          radius="lg"
          className="max-w-[400px]"
          inputSize="sm"
        />

        <Button variant="ghost" color="primary">
          Primary Button
        </Button>

        <PhoneInput
          label="Phone Number"
          defaultCountry="IN"
          onChange={(number, country) => {
            console.log(`${country.dialCode}${number}`);
          }}
        />
      </section>
    </>
  );
}
