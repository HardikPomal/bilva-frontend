(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/2e827_next_dist_compiled_next-devtools_index_4d11a110.js",
  "static/chunks/2e827_next_dist_compiled_a773c945._.js",
  "static/chunks/2e827_next_dist_shared_lib_fa6709d4._.js",
  "static/chunks/2e827_next_dist_client_1040f14b._.js",
  "static/chunks/2e827_next_dist_562e8f46._.js",
  "static/chunks/2e827_next_app_9da042d4.js",
  "static/chunks/[next]_entry_page-loader_ts_e02e16d8._.js",
  "static/chunks/2e827_react-dom_72314d48._.js",
  "static/chunks/2e827_f009afa0._.js",
  "static/chunks/[root-of-the-server]__8be920f7._.js"
],
    source: "entry"
});
