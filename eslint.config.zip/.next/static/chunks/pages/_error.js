__turbopack_load_page_chunks__("/_error", [
  "static/chunks/2e827_next_dist_compiled_next-devtools_index_4d11a110.js",
  "static/chunks/2e827_next_dist_compiled_a773c945._.js",
  "static/chunks/2e827_next_dist_shared_lib_2b8a3416._.js",
  "static/chunks/2e827_next_dist_client_1040f14b._.js",
  "static/chunks/2e827_next_dist_1af05534._.js",
  "static/chunks/2e827_next_error_2a2f504e.js",
  "static/chunks/[next]_entry_page-loader_ts_e5c4fab8._.js",
  "static/chunks/2e827_react-dom_72314d48._.js",
  "static/chunks/2e827_f009afa0._.js",
  "static/chunks/[root-of-the-server]__74b9e1ec._.js",
  "static/chunks/B_B FrontEnd_bilva-frontend_pages__error_2da965e7._.js",
  "static/chunks/turbopack-B_B FrontEnd_bilva-frontend_pages__error_bc003a3e._.js"
])
