(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/B_B FrontEnd_bilva-frontend_src_app_globals_9ba68196.css",
  "static/chunks/B_B FrontEnd_bilva-frontend_src_components_ThemeProvider_tsx_303fd6d6._.js"
],
    source: "dynamic"
});
