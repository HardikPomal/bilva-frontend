(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/B_B FrontEnd_bilva-frontend_3ab83831._.js"
],
    source: "dynamic"
});
