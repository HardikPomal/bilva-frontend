(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_ed42b7b1._.js",
  "static/chunks/2e827_next_dist_compiled_react-dom_3f28b5fe._.js",
  "static/chunks/2e827_next_dist_compiled_next-devtools_index_a4e8e483.js",
  "static/chunks/2e827_next_dist_compiled_bb8a46b5._.js",
  "static/chunks/2e827_next_dist_client_442dbac5._.js",
  "static/chunks/2e827_next_dist_b1b08fd0._.js",
  "static/chunks/2e827_@swc_helpers_cjs_c8011fa8._.js"
],
    source: "entry"
});
