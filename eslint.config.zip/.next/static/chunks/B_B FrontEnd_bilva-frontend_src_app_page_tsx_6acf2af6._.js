(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/2e827_next_dist_781f72f5._.js",
  "static/chunks/B_B FrontEnd_bilva-frontend_src_app_page_module_c37570e6.css"
],
    source: "dynamic"
});
