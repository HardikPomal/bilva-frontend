module.exports = [
"[project]/B/B FrontEnd/bilva-frontend/.next-internal/server/app/button/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=7b4be_bilva-frontend__next-internal_server_app_button_page_actions_03e815e2.js.map