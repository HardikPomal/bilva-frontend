module.exports = [
"[project]/B/B FrontEnd/bilva-frontend/src/app/favicon.ico.mjs { IMAGE => \"[project]/B/B FrontEnd/bilva-frontend/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/B/B FrontEnd/bilva-frontend/src/app/favicon.ico.mjs { IMAGE => \"[project]/B/B FrontEnd/bilva-frontend/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[project]/B/B FrontEnd/bilva-frontend/src/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/B/B FrontEnd/bilva-frontend/src/app/layout.tsx [app-rsc] (ecmascript)"));
}),
];