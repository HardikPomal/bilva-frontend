module.exports = [
"[project]/B/B FrontEnd/bilva-frontend/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
"[project]/B/B FrontEnd/bilva-frontend/src/app/favicon.ico.mjs { IMAGE => \"[project]/B/B FrontEnd/bilva-frontend/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/B/B FrontEnd/bilva-frontend/src/app/favicon.ico.mjs { IMAGE => \"[project]/B/B FrontEnd/bilva-frontend/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[project]/B/B FrontEnd/bilva-frontend/src/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/B/B FrontEnd/bilva-frontend/src/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/B/B FrontEnd/bilva-frontend/src/components/ui/button.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/B/B FrontEnd/bilva-frontend/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f40$iconify$2f$react$2f$dist$2f$iconify$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/B/B FrontEnd/bilva-frontend/node_modules/@iconify/react/dist/iconify.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/B/B FrontEnd/bilva-frontend/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
;
;
;
const Button = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"].forwardRef(({ size = "md", variant = "solid", color = "primary", rounded = "md", leftIcon, rightIcon, iconSize = 20, children, className = "", disabled, ...props }, ref)=>{
    // Size classes
    const sizeClasses = {
        xs: "px-1 py-0.5",
        sm: "px-2 py-1",
        md: "px-3 py-2",
        lg: "px-4 py-3"
    };
    // Base rounded classes
    const roundedBaseClasses = {
        none: "rounded-none",
        sm: "rounded",
        md: "rounded-md",
        lg: "rounded-md",
        xl: "rounded-2xl",
        "2xl": "rounded-2xl",
        full: "rounded-full"
    };
    // Disabled rounded classes
    const roundedDisabledClasses = {
        none: "disabled:hover:rounded-none",
        sm: "disabled:hover:rounded",
        md: "disabled:hover:rounded",
        lg: "disabled:hover:rounded",
        xl: "disabled:hover:rounded",
        "2xl": "disabled:hover:rounded-2xl",
        full: "disabled:hover:rounded-full"
    };
    // Variant-specific color classes
    const variantClasses = {
        solid: {
            primary: "text-base-50 bg-primary-500 hover:bg-primary-700 active:bg-primary-800 disabled:hover:bg-primary-500",
            secondary: "text-base-50 bg-secondary-500 hover:bg-secondary-700 active:bg-secondary-800 disabled:hover:bg-secondary-500",
            pending: "text-base-50 bg-pending-500 hover:bg-pending-700 active:bg-pending-800 disabled:hover:bg-pending-500",
            success: "text-base-50 bg-success-500 hover:bg-success-700 active:bg-success-800 disabled:hover:bg-success-500",
            danger: "text-base-50 bg-danger-500 hover:bg-danger-700 active:bg-danger-800 disabled:hover:bg-danger-500",
            base: "text-base-50 bg-base-950 hover:bg-base-700 active:bg-base-800 disabled:hover:bg-base-950"
        },
        outline: {
            primary: "text-primary-500 hover:text-primary-700 active:text-primary-800 outline outline-primary-500 hover:outline-primary-700 active:outline-primary-800 bg-transparent hover:bg-primary-100 active:bg-primary-200 disabled:hover:bg-transparent disabled:hover:text-primary-500",
            secondary: "text-secondary-500 hover:text-secondary-700 active:text-secondary-800 outline outline-secondary-500 hover:outline-secondary-700 active:outline-secondary-800 bg-transparent hover:bg-secondary-100 active:bg-secondary-200 disabled:hover:bg-transparent disabled:hover:text-secondary-500",
            pending: "text-pending-500 hover:text-pending-700 active:text-pending-800 outline outline-pending-500 hover:outline-pending-700 active:outline-pending-800 bg-transparent hover:bg-pending-100 active:bg-pending-200 disabled:hover:bg-transparent disabled:hover:text-pending-500",
            success: "text-success-500 hover:text-success-700 active:text-success-800 outline outline-success-500 hover:outline-success-700 active:outline-success-800 bg-transparent hover:bg-success-100 active:bg-success-200 disabled:hover:bg-transparent disabled:hover:text-success-500",
            danger: "text-danger-500 hover:text-danger-700 active:text-danger-800 outline outline-danger-500 hover:outline-danger-700 active:outline-danger-800 bg-transparent hover:bg-danger-100 active:bg-danger-200 disabled:hover:bg-transparent disabled:hover:text-danger-500",
            base: "text-base-950 hover:text-base-700 active:text-base-950 outline outline-base-500 hover:outline-base-700 active:outline-base-800 bg-transparent hover:bg-base-200 active:bg-base-300 disabled:hover:bg-transparent disabled:hover:text-base-950"
        },
        ghost: {
            primary: "text-primary-500 hover:text-primary-700 active:text-primary-800 active:outline-primary-800 bg-transparent hover:bg-primary-100 active:bg-primary-200 disabled:hover:bg-transparent disabled:hover:text-primary-500",
            secondary: "text-secondary-500 hover:text-secondary-700 active:text-secondary-800 active:outline-secondary-800 bg-transparent hover:bg-secondary-100 active:bg-secondary-200 disabled:hover:bg-transparent disabled:hover:text-secondary-500",
            pending: "text-pending-500 hover:text-pending-700 active:text-pending-800 active:outline-pending-800 bg-transparent hover:bg-pending-100 active:bg-pending-200 disabled:hover:bg-transparent disabled:hover:text-pending-500",
            success: "text-success-500 hover:text-success-700 active:text-success-800 active:outline-success-800 bg-transparent hover:bg-success-100 active:bg-success-200 disabled:hover:bg-transparent disabled:hover:text-success-500",
            danger: "text-danger-500 hover:text-danger-700 active:text-danger-800 active:outline-danger-800 bg-transparent hover:bg-danger-100 active:bg-danger-200 disabled:hover:bg-transparent disabled:hover:text-danger-500",
            base: "text-base-950 hover:text-base-700 active:text-base-950 active:outline-base-800 bg-transparent hover:bg-base-200 active:bg-base-300 disabled:hover:bg-transparent disabled:hover:text-base-950"
        }
    };
    // Special handling for outline variant disabled rounded
    const outlineDisabledRounded = variant === "outline" && (rounded === "full" || rounded === "2xl") ? "disabled:rounded-2xl" : roundedDisabledClasses[rounded];
    const classes = `${sizeClasses[size]} ${roundedBaseClasses[rounded]} ${outlineDisabledRounded} ${variantClasses[variant][color]} w-fit h-fit flex items-center gap-1 ${className}`.trim();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        ref: ref,
        className: classes,
        disabled: disabled,
        ...props,
        children: [
            leftIcon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f40$iconify$2f$react$2f$dist$2f$iconify$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Icon"], {
                icon: leftIcon,
                width: iconSize,
                height: iconSize
            }, void 0, false, {
                fileName: "[project]/B/B FrontEnd/bilva-frontend/src/components/ui/button.tsx",
                lineNumber: 126,
                columnNumber: 22
            }, ("TURBOPACK compile-time value", void 0)),
            children && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "p-text",
                children: children
            }, void 0, false, {
                fileName: "[project]/B/B FrontEnd/bilva-frontend/src/components/ui/button.tsx",
                lineNumber: 127,
                columnNumber: 22
            }, ("TURBOPACK compile-time value", void 0)),
            rightIcon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f40$iconify$2f$react$2f$dist$2f$iconify$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Icon"], {
                icon: rightIcon,
                width: iconSize,
                height: iconSize
            }, void 0, false, {
                fileName: "[project]/B/B FrontEnd/bilva-frontend/src/components/ui/button.tsx",
                lineNumber: 128,
                columnNumber: 23
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/components/ui/button.tsx",
        lineNumber: 125,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
Button.displayName = "Button";
const __TURBOPACK__default__export__ = Button;
}),
"[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Home
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/B/B FrontEnd/bilva-frontend/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/B/B FrontEnd/bilva-frontend/src/components/ui/button.tsx [app-rsc] (ecmascript)");
;
;
function Home() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "title py-10 mx-auto text-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        children: "This is a Bilva System for Testing"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 8,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: "Here I am going to Test and Develop the Reusable Components."
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 9,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                lineNumber: 7,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "components container mx-auto grid grid-cols-7",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "primary",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 15,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "primary",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 25,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "primary",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 35,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "primary",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 45,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "primary",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 55,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "primary",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 65,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "primary",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 75,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "primary",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 85,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "primary",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 95,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "primary",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 105,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "primary",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 115,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "primary",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 125,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "primary",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 135,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "primary",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 145,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "primary",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 155,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "primary",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 165,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "primary",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 175,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "primary",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 185,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "primary",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 195,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "primary",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 205,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "primary",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 215,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "secondary",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 225,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "secondary",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 235,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "secondary",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 245,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "secondary",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 255,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "secondary",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 265,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "secondary",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 275,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "secondary",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 285,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "secondary",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 295,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "secondary",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 305,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "secondary",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 315,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "secondary",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 325,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "secondary",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 335,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "secondary",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 345,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "secondary",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 355,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "secondary",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 365,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "secondary",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 375,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "secondary",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 385,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "secondary",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 395,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "secondary",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 405,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "secondary",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 415,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "secondary",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 425,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "success",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 435,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "success",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 445,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "success",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 455,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "success",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 465,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "success",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 475,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "success",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 485,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "success",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 495,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "success",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 505,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "success",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 515,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "success",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 525,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "success",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 535,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "success",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 545,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "success",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 555,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "success",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 565,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "success",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 575,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "success",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 585,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "success",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 595,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "success",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 605,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "success",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 615,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "success",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 625,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "success",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 635,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "pending",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 645,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "pending",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 655,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "pending",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 665,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "pending",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 675,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "pending",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 685,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "pending",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 695,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "pending",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 705,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "pending",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 715,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "pending",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 725,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "pending",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 735,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "pending",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 745,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "pending",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 755,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "pending",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 765,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "pending",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 775,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "pending",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 785,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "pending",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 795,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "pending",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 805,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "pending",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 815,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "pending",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 825,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "pending",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 835,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "pending",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 845,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "danger",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 855,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "danger",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 865,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "danger",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 875,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "danger",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 885,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "danger",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 895,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "danger",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 905,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "danger",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 915,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "danger",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 925,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "danger",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 935,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "danger",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 945,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "danger",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 955,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "danger",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 965,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "danger",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 975,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "danger",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 985,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "danger",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 995,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "danger",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1005,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "danger",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1015,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "danger",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1025,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "danger",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1035,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "danger",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1045,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "danger",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1055,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "base",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1065,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "base",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1075,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "base",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1085,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "base",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1095,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "base",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1105,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "base",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1115,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "solid",
                        color: "base",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1125,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "base",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1135,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "base",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1145,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "base",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1155,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "base",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1165,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "base",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1175,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "base",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1185,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "outline",
                        color: "base",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1195,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "base",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1205,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "base",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1215,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "base",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1225,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "base",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1235,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "base",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1245,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "base",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1255,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "xs",
                        variant: "ghost",
                        color: "base",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1265,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "primary",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1275,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "primary",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1285,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "primary",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1295,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "primary",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1305,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "primary",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1315,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "primary",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1325,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "primary",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1335,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "primary",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1345,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "primary",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1355,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "primary",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1365,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "primary",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1375,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "primary",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1385,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "primary",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1395,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "primary",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1405,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "primary",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1415,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "primary",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1425,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "primary",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1435,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "primary",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1445,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "primary",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1455,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "primary",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1465,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "primary",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1475,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "secondary",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1485,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "secondary",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1495,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "secondary",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1505,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "secondary",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1515,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "secondary",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1525,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "secondary",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1535,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "secondary",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1545,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "secondary",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1555,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "secondary",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1565,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "secondary",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1575,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "secondary",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1585,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "secondary",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1595,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "secondary",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1605,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "secondary",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1615,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "secondary",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1625,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "secondary",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1635,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "secondary",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1645,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "secondary",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1655,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "secondary",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1665,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "secondary",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1675,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "secondary",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1685,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "success",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1695,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "success",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1705,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "success",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1715,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "success",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1725,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "success",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1735,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "success",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1745,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "success",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1755,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "success",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1765,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "success",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1775,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "success",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1785,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "success",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1795,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "success",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1805,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "success",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1815,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "success",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1825,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "success",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1835,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "success",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1845,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "success",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1855,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "success",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1865,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "success",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1875,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "success",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1885,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "success",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1895,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "pending",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1905,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "pending",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1915,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "pending",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1925,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "pending",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1935,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "pending",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1945,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "pending",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1955,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "pending",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1965,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "pending",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1975,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "pending",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1985,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "pending",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 1995,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "pending",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2005,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "pending",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2015,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "pending",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2025,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "pending",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2035,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "pending",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2045,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "pending",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2055,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "pending",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2065,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "pending",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2075,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "pending",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2085,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "pending",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2095,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "pending",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2105,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "danger",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2115,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "danger",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2125,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "danger",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2135,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "danger",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2145,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "danger",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2155,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "danger",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2165,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "danger",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2175,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "danger",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2185,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "danger",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2195,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "danger",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2205,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "danger",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2215,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "danger",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2225,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "danger",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2235,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "danger",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2245,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "danger",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2255,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "danger",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2265,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "danger",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2275,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "danger",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2285,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "danger",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2295,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "danger",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2305,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "danger",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2315,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "base",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2325,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "base",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2335,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "base",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2345,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "base",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2355,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "base",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2365,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "base",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2375,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "solid",
                        color: "base",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2385,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "base",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2395,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "base",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2405,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "base",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2415,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "base",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2425,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "base",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2435,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "base",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2445,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "outline",
                        color: "base",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2455,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "base",
                        rounded: "none",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2465,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "base",
                        rounded: "sm",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2475,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "base",
                        rounded: "md",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2485,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "base",
                        rounded: "lg",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2495,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "base",
                        rounded: "xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2505,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "base",
                        rounded: "2xl",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2515,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$B$2f$B__FrontEnd$2f$bilva$2d$frontend$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        size: "sm",
                        variant: "ghost",
                        color: "base",
                        rounded: "full",
                        leftIcon: "fluent:home-20-regular",
                        rightIcon: "fluent:arrow-right-20-regular",
                        children: "Button"
                    }, void 0, false, {
                        fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                        lineNumber: 2525,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx",
                lineNumber: 12,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
}),
"[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/B/B FrontEnd/bilva-frontend/src/app/page.tsx [app-rsc] (ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__476621c4._.js.map