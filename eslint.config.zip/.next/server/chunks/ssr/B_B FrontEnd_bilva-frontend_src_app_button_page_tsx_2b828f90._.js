module.exports = [
"[project]/B/B FrontEnd/bilva-frontend/src/app/button/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/B/B FrontEnd/bilva-frontend/src/app/button/page.tsx [app-rsc] (ecmascript)"));
}),
];