var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/2e827_next_5b9aed73._.js")
R.c("server/chunks/[root-of-the-server]__0a1bebe8._.js")
R.m("[project]/B/B FrontEnd/bilva-frontend/.next-internal/server/app/favicon.ico/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/B/B FrontEnd/bilva-frontend/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/B/B FrontEnd/bilva-frontend/src/app/favicon--route-entry.js [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/B/B FrontEnd/bilva-frontend/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/B/B FrontEnd/bilva-frontend/src/app/favicon--route-entry.js [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
