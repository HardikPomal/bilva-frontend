globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/2e827_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_ed42b7b1._.js",
    "static/chunks/2e827_next_dist_compiled_react-dom_3f28b5fe._.js",
    "static/chunks/2e827_next_dist_compiled_next-devtools_index_a4e8e483.js",
    "static/chunks/2e827_next_dist_compiled_bb8a46b5._.js",
    "static/chunks/2e827_next_dist_client_442dbac5._.js",
    "static/chunks/2e827_next_dist_b1b08fd0._.js",
    "static/chunks/2e827_@swc_helpers_cjs_c8011fa8._.js",
    "static/chunks/B_B FrontEnd_bilva-frontend_a0ff3932._.js",
    "static/chunks/turbopack-B_B FrontEnd_bilva-frontend_545a042b._.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];