var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[root-of-the-server]__0b103398._.js")
R.m("[project]/B/B FrontEnd/bilva-frontend/node_modules/next/app.js [ssr] (ecmascript)")
module.exports=R.m("[project]/B/B FrontEnd/bilva-frontend/node_modules/next/app.js [ssr] (ecmascript)").exports
