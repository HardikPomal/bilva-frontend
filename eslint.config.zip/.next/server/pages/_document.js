var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/2e827_b9500d40._.js")
R.c("server/chunks/ssr/[root-of-the-server]__e6a4d965._.js")
R.m("[project]/B/B FrontEnd/bilva-frontend/node_modules/next/document.js [ssr] (ecmascript)")
module.exports=R.m("[project]/B/B FrontEnd/bilva-frontend/node_modules/next/document.js [ssr] (ecmascript)").exports
